/*
 * ListClient.java
 * 
 * CS 112 - Lab 8
 */

public class ListClient {
    public static void main(String[] args) {
        List vals1 = new ArrayList(10);
        
        // Do **NOT** change these lines!
        vals1.addItem("hello", 0);
        vals1.addItem("world!", 0);
        vals1.addItem("how", 1);
        vals1.addItem("are", 1);
        vals1.addItem("you?", 2);
        System.out.println(vals1);
        
        // Add lines below to reorder the items in vals1 as instructed,
        // and then print the new contents of vals1.
        
    }
}